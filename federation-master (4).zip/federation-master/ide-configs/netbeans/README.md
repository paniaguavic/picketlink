For instructions see http://community.jboss.org/wiki/ImportFormattingRules#Netbeans
